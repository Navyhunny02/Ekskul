<?php

include("../dbconnect.php");

if (isset($_POST['submit'])) {
    $nisn = $_POST['nisn'];
    $hobi = $_POST['hobi'];
    $namalengkap = $_POST['namalengkap'];
    $kelamin = $_POST['jeniskelamin'];
    $id = $_POST['id'] ?? null;
    $kelas = $_POST['kelas'];
    $telepon = $_POST['telepon'];

    $ekskul = $_POST['ekskul'];
    $pengalaman = $_POST['pengalaman'];
    $sertifikat = 'sertifikat_' . $nisn;

    //perihal gambar
    $nama_file_foto = $_FILES['sertifikat']['name'];
    $ext1 = pathinfo($nama_file_foto, PATHINFO_EXTENSION);
    $ukuran_file_sertifikat = $_FILES['sertifikat']['size'];
    $ukurantotal = $ukuran_file_sertifikat;
    $tipe_file = $_FILES['sertifikat']['type'];
    $tmp_file = $_FILES['sertifikat']['tmp_name'];
    $path_sertifikat = "images/sertifikat/" . $sertifikat . '.' . $ext1;

    // Pastikan direktori untuk menyimpan sertifikat sudah ada
    $sertifikat_directory = 'images/sertifikat/';
    if (!is_dir($sertifikat_directory)) {
        mkdir($sertifikat_directory, 0755, true);
    }

    // Pindahkan file sertifikat ke direktori yang ditentukan
    if (move_uploaded_file($tmp_file, $path_sertifikat)) {
        $submitdata = mysqli_query($conn, "INSERT INTO siswa (userid, nisn, hobi, namalengkap, jeniskelamin, kelas, telepon, ekskul, pengalaman, sertifikat)   	
                      VALUES ('$userid','$nisn','$hobi','$namalengkap','$kelamin','$kelas','$telepon', '$ekskul', '$pengalaman', '$path_sertifikat')");

        if ($submitdata) {
            echo " <div class='alert alert-success'>
                    Berhasil submit data.
                </div>
                <meta http-equiv='refresh' content='2; url=daftar.php'/>  ";
        } else {
            echo "<div class='alert alert-warning'>
                    Gagal submit data. Silakan coba lagi nanti.
                </div>
                <meta http-equiv='refresh' content='3; url=daftar.php'/> ";
        }
    } else {
        // Jika gagal memindahkan file, berikan pesan kesalahan
        echo "Sorry, there's a problem while uploading the file.";
        echo "<br><meta http-equiv='refresh' content='5; URL=daftar.php'> You will be redirected to the form in 5 seconds";
    }
};

/*
    //kalau update
    if(isset($_POST['update'])){
      $userid = $_POST['userid'];
      $telepon = $_POST['telepon'];

    $update = mysqli_query($conn,"update siswa
    set telepon='$telepon' where userid='$id'");

    if($update){ 

      //berhasil bikin
      echo " <div class='alert alert-success'>
              Berhasil submit data.
          </div>
          <meta http-equiv='refresh' content='1; url= mydata.php'/>  ";  

    }else{
      echo "<div class='alert alert-warning'>
              Gagal submit data. Silakan coba lagi nanti.
          </div>
          <meta http-equiv='refresh' content='3; url= mydata.php'/> ";
      }
    };
*/

//get timezone jkt
date_default_timezone_set("Asia/Bangkok");
$today = date("Y-m-d"); //now

    //kalau konfirmasi
    if(isset($_POST['ok'])){
      $id = $_POST['id'];
      $updateaja = mysqli_query($conn,"update siswa set status='Verified', tglkonfirmasi='$today' where userid='$id'");

      if($updateaja){
        //berhasil bikin
          echo " <div class='alert alert-success'>
          Berhasil submit data.
      </div>
      <meta http-equiv='refresh' content='1; url= mydata.php'/>  ";  
      } else {
        echo "<div class='alert alert-warning'>
              Gagal submit data. Silakan coba lagi nanti.
          </div>
          <meta http-equiv='refresh' content='3; url= mydata.php'/> ";
      }
    };
?>