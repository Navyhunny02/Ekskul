<?php
namespace Dompdf;

class Helpers
{
    public static function pre_r($mixed, $return = false)
    {
        if ($return) {
            return "<pre>" . print_r($mixed, true) . "</pre>";
        }

        if (php_sapi_name() !== "cli") {
            echo "<pre>";
        }

        print_r($mixed);

        if (php_sapi_name() !== "cli") {
            echo "</pre>";
        } else {
            echo "\n";
        }

        flush();

        return null;
    }

    public static function build_url($protocol, $host, $base_path, $url)
    {
        $protocol = mb_strtolower($protocol);
        if (strlen($url) == 0) {
            return $protocol . $host . $base_path;
        }

        if (
            mb_strpos($url, "://") !== false ||
            mb_substr($url, 0, 1) === "#" ||
            mb_strpos($url, "data:") === 0 ||
            mb_strpos($url, "mailto:") === 0 ||
            mb_strpos($url, "tel:") === 0
        ) {
            return $url;
        }

        $ret = $protocol;

        if (!in_array(mb_strtolower($protocol), array("http://", "https://", "ftp://", "ftps://"))) {
            if ($url[0] !== '/' && (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN' || (mb_strlen($url) > 1 && $url[0] !== '\\' && $url[1] !== ':'))) {
                $ret .= realpath($base_path) . '/';
            }
            $ret .= $url;
            $ret = preg_replace('/\?(.*)$/', "", $ret);
            return $ret;
        }

        if (strpos($url, '//') === 0) {
            $ret .= substr($url, 2);
        } elseif ($url[0] === '/' || $url[0] === '\\') {
            $ret .= $host . $url;
        } else {
            $ret .= $host . $base_path . $url;
        }

        return $ret;
    }

    public static function buildContentDispositionHeader($dispositionType, $filename)
    {
        $encoding = mb_detect_encoding($filename);
        $fallbackfilename = mb_convert_encoding($filename, "ISO-8859-1", $encoding);
        $fallbackfilename = str_replace("\"", "", $fallbackfilename);
        $encodedfilename = rawurlencode($filename);

        $contentDisposition = "Content-Disposition: $dispositionType; filename=\"$fallbackfilename\"";
        if ($fallbackfilename !== $filename) {
            $contentDisposition .= "; filename*=UTF-8''$encodedfilename";
        }

        return $contentDisposition;
    }

    public static function dec2roman($num)
    {
        static $ones = array("", "i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix");
        static $tens = array("", "x", "xx", "xxx", "xl", "l", "lx", "lxx", "lxxx", "xc");
        static $hund = array("", "c", "cc", "ccc", "cd", "d", "dc", "dcc", "dccc", "cm");
        static $thou = array("", "m", "mm", "mmm");

        if (!is_numeric($num)) {
            throw new Exception("dec2roman() requires a numeric argument.");
        }

        if ($num > 4000 || $num < 0) {
            return "(out of range)";
        }

        $num = strrev((string) $num);

        $ret = "";
        switch (mb_strlen($num)) {
            case 4:
                $ret .= $thou[$num[3]];
            case 3:
                $ret .= $hund[$num[2]];
            case 2:
                $ret .= $tens[$num[1]];
            case 1:
                $ret .= $ones[$num[0]];
            default:
                break;
        }

        return $ret;
    }

    public static function is_percent($value)
    {
        return false !== mb_strpos($value, "%");
    }

    public static function parse_data_uri($data_uri)
    {
        if (!preg_match('/^data:(?P<mime>[a-z0-9\/+-.]+)(;charset=(?P<charset>[a-z0-9-])+)?(?P<base64>;base64)?\,(?P<data>.*)?/is', $data_uri, $match)) {
            return false;
        }

        $result = array(
            'mime' => $match['mime'],
            'charset' => isset($match['charset']) ? $match['charset'] : null,
            'base64' => isset($match['base64']) ? true : false,
            'data' => $match['data'],
        );

        return $result;
    }

    public static function encodeURI($uri)
    {
        return rawurlencode(rawurldecode($uri));
    }

    public static function rle8_decode($str, $width)
    {
        $out = "";
        $len = mb_strlen($str);
        $i = 0;
        while ($i < $len) {
            $count = ord($str[$i++]);
            if ($count < 128) {
                $out .= substr($str, $i, $count);
                $i += $count;
            } else {
                $count = 256 - $count + 1;
                $out .= str_repeat($str[$i++], $count);
            }
        }

        return str_pad($out, $width);
    }

    public static function rle4_decode($str, $width)
    {
        $out = "";
        $len = mb_strlen($str);
        $i = 0;
        $nibble = 0;
        $nibble_count = 0;

        while ($i < $len) {
            $byte = ord($str[$i++]);
            $nibble_count++;
            if ($nibble_count % 2) {
                $nibble = ($byte & 0xf0) >> 4;
            } else {
                $nibble = $byte & 0x0f;
            }

            if ($nibble_count == 2) {
                $out .= str_repeat(dechex($nibble), 8);
            } else {
                $out .= dechex($nibble);
            }
        }

        return str_pad($out, $width);
    }

    public static function explode_url($url)
    {
        $parts = parse_url($url);

        $result = array(
            'protocol' => isset($parts['scheme']) ? $parts['scheme'] . '://' : '',
            'host' => isset($parts['host']) ? $parts['host'] : '',
            'path' => isset($parts['path']) ? $parts['path'] : '',
            'file' => isset($parts['path']) ? basename($parts['path']) : '',
        );

        return $result;
    }

    public static function dompdf_debug($type, $msg)
    {
        if (defined("DEBUGPNG") && DEBUGPNG == true) {
            error_log("[DOMPDF][DEBUG $type] $msg");
        }
    }

    public static function record_warnings($errno, $errstr, $errfile, $errline)
    {
        if (!(error_reporting() & $errno)) {
            return;
        }

        $errtype = "E_UNKNOWN";

        switch ($errno) {
            case E_WARNING:
                $errtype = "E_WARNING";
                break;
            case E_NOTICE:
                $errtype = "E_NOTICE";
                break;
            case E_USER_ERROR:
                $errtype = "E_USER_ERROR";
                break;
            case E_USER_WARNING:
                $errtype = "E_USER_WARNING";
                break;
            case E_USER_NOTICE:
                $errtype = "E_USER_NOTICE";
                break;
            case E_STRICT:
                $errtype = "E_STRICT";
                break;
            case E_RECOVERABLE_ERROR:
                $errtype = "E_RECOVERABLE_ERROR";
                break;
        }

        $GLOBALS["_dompdf_warnings"][$errno][] = array(
            "type" => $errtype,
            "message" => $errstr,
            "file" => $errfile,
            "line" => $errline,
        );

        /* Don't execute PHP internal error handler */
        return true;
    }

    public static function unichr($c)
    {
        return mb_convert_encoding('&#' . intval($c) . ';', 'UTF-8', 'HTML-ENTITIES');
    }

    public static function cmyk_to_rgb($c, $m, $y, $k)
    {
        $r = (1 - min(1, $c + $k)) * 255;
        $g = (1 - min(1, $m + $k)) * 255;
        $b = (1 - min(1, $y + $k)) * 255;

        return array($r, $g, $b);
    }

    public static function dompdf_getimagesize($filename, $context)
    {
        $data = @getimagesize($filename, $context);

        if (!$data && function_exists("exif_imagetype")) {
            $data = array(0, 0, 0);
            $img_type = exif_imagetype($filename);

            switch ($img_type) {
                case IMAGETYPE_GIF:
                    $data['mime'] = 'image/gif';
                    break;
                case IMAGETYPE_JPEG:
                    $data['mime'] = 'image/jpeg';
                    break;
                case IMAGETYPE_PNG:
                    $data['mime'] = 'image/png';
                    break;
            }
        }

        return $data;
    }

    public static function imagecreatefrombmp($filename, $context)
    {
        if (!function_exists("imagecreatefrombmp")) {
            $data = self::getFileContent($filename, $context);

            if (!$data) {
                return false;
            }

            return self::imagecreatefrombmpstring($data);
        } else {
            return imagecreatefrombmp($filename);
        }
    }

    public static function getFileContent($filename, $context)
    {
        if (isset($context) && is_resource($context)) {
            fseek($context, 0);
            $data = "";
            while (!feof($context)) {
                $data .= fread($context, 8192);
            }
            return $data;
        } elseif (is_file($filename)) {
            return file_get_contents($filename);
        } elseif (is_string($filename) && preg_match("/^data:/", $filename)) {
            // Data URI
            return self::parse_data_uri($filename)['data'];
        } else {
            return false;
        }
    }

    private static function imagecreatefrombmpstring($data)
    {
        $tmpfile = tempnam(sys_get_temp_dir(), 'bmp');
        if (!$tmpfile) {
            return false;
        }

        file_put_contents($tmpfile, $data);
        $img = imagecreatefrombmp($tmpfile);
        unlink($tmpfile);

        return $img;
    }
}
