
<?php 
    include 'dbconnect.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>Pendaftaran Ekstrakurikuler Siswa SMPN 14 Solok Selatan</title>
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.13.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="#page-top">EKSKUL</a>
                <button class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#ekskul">Jenis Ekskul</a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#panduan">Panduan</a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="login.php">Login</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead bg-primary text-white text-center">
            <div class="container d-flex align-items-center flex-column">
                <!-- Masthead Avatar Image-->
                <img src="assets/img/ekstrakurikuler.png" alt="" width="450" />
                <!-- Masthead Heading-->
                <h1 class="masthead-heading text-uppercase mb-0">Pendaftaran Ekstrakurikuler</h1>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Masthead Subheading-->
                <p class="masthead-subheading font-weight-light mb-0">Siswa SMPN 14 Solok Selatan</p>
            </div>
        </header>
        <!-- Portfolio Section-->
        <section class="page-section portfolio" id="ekskul">
            <div class="container">
                <!-- Portfolio Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Jenis Ekskul</h2>
                <!-- Icon Divider-->
                <div class="divider-custom">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Portfolio Grid Items-->
                <div class="row">
                    <!-- Portfolio Item 1-->
                    <div class="col-md-6 col-lg-4 mb-5">
                        <div class="portfolio-item mx-auto" data-toggle="modal" data-target="#portfolioModal1">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div>
			    <div style="text-align: center;">
                            	<img src="assets/img/portfolio/pramuka.png" alt="" height="200"/>
			    </div>
                        </div>
                    </div>
                    <!-- Portfolio Item 2-->
                    <div class="col-md-6 col-lg-4 mb-5">
                        <div class="portfolio-item mx-auto" data-toggle="modal" data-target="#portfolioModal2">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div>
			    <div style="text-align: center;">
                            	<img src="assets/img/portfolio/Tahfidz.webp" alt="" height="200"/>
			    </div>
                        </div>
                    </div>
                    <!-- Portfolio Item 3-->
                    <div class="col-md-6 col-lg-4 mb-5">
                        <div class="portfolio-item mx-auto" data-toggle="modal" data-target="#portfolioModal3">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div>
			    <div style="text-align: center;">
                            	<img src="assets/img/portfolio/EnglishClub.png" alt="" height="200"/>
			    </div>
                        </div>
                    </div>
                    <!-- Portfolio Item 4-->
                    <div class="col-md-6 col-lg-4 mb-5 mb-lg-0">
                        <div class="portfolio-item mx-auto" data-toggle="modal" data-target="#portfolioModal4">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div>
                            <img src="assets/img/portfolio/olahraga.png" alt="" height="200" />
                        </div>
                    </div>
                    <!-- Portfolio Item 5-->
                    <div class="col-md-6 col-lg-4 mb-5 mb-md-0">
                        <div class="portfolio-item mx-auto" data-toggle="modal" data-target="#portfolioModal5">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div>
			    <div style="text-align: center;">
                            	<img src="assets/img/portfolio/pencak-silat.png" alt="" height="200"/>
			    </div>
                        </div>
                    </div>
                    <!-- Portfolio Item 6-->
                    <div class="col-md-6 col-lg-4">
                        <div class="portfolio-item mx-auto" data-toggle="modal" data-target="#portfolioModal6">
                            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                                <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                            </div>
                            <img src="assets/img/portfolio/Drumband.jpg" alt="" height="200"/>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        
<!-- Portfolio Section-->
<section class="page-section portfolio" id="ekskul">
    <div class="container">
        <!-- Portfolio Section Heading-->
        <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Informasi</h2>
        <!-- Icon Divider-->
        <div class="divider-custom">
            <div class="divider-custom-line"></div>
            <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
            <div class="divider-custom-line"></div>
        </div>
        <!-- Portfolio Grid Items-->
        <table id="dataTable3" class="table table-hover mt-5" style="width:100%"><thead class="thead-dark">
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Ekskul</th>
                                        <th>Nama Informasi</th>
                                        <th>Deskripsi</th>
                                        
                                    </tr></thead><tbody>
                                    <?php 
                                    $form=mysqli_query($conn,"SELECT * FROM informasi join ekstrakurikuler on informasi.id_ekskul = ekstrakurikuler.id_ekskul ORDER BY id_informasi ASC");
                                    $no=1;
                                    while($data=mysqli_fetch_array($form)) :

                                        ?>
                                        
                                        
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td><?= $data['nama_ekskul'] ?></td>
                                            <td><?= $data['nama_informasi'] ?></td>
                                            <td><?= $data['deskripsi'] ?></td>
                                        </tr>		
                                        
                                        <?php endwhile; ?>
                                </tbody>
                                </table>
        
    </div>
</section>





        
        <!-- Portfolio Section-->
        <section class="page-section portfolio" id="ekskul">
            <div class="container">
                <!-- Portfolio Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Progress</h2>
                <!-- Icon Divider-->
                <div class="divider-custom">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Portfolio Grid Items-->
                <table id="dataTable3" class="table table-hover mt-5" style="width:100%"><thead class="thead-dark">
											<tr>
												<th>No</th>
												<th>Nama Ekskul</th>
												<th>Nama Progress</th>
												<th>Tanggal</th>
												<th>Deskripsi</th>
												
											</tr></thead><tbody>
											<?php 
											$form=mysqli_query($conn,"SELECT * FROM progress join ekstrakurikuler on progress.id_ekskul = ekstrakurikuler.id_ekskul  ORDER BY id_progress ASC");
											$no=1;
											while($data=mysqli_fetch_array($form)) :

												?>
												
                                                
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $data['nama_ekskul'] ?></td>
													<td><?= $data['nama_progress'] ?></td>
                                                    <td><?= $data['tanggal'] ?></td>
                                                    <td><?= $data['deskripsi'] ?></td>
												</tr>		
                                                
                                                <?php endwhile; ?>
										</tbody>
										</table>
                
            </div>
        </section>

        
<!-- Portfolio Section-->
<section class="page-section portfolio" id="ekskul">
    <div class="container">
        <!-- Portfolio Section Heading-->
        <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Guru</h2>
        <!-- Icon Divider-->
        <div class="divider-custom">
            <div class="divider-custom-line"></div>
            <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
            <div class="divider-custom-line"></div>
        </div>
        <!-- Portfolio Grid Items-->
        <table id="data-table-guru" class="table table-hover mt-5" style="width:100%"><thead class="thead-dark">
                                    <thead>
                                        <tr>
                                        <th>Nama</th>
                                        <th>NIP</th>
                                        <th>Jenis Kelamin</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Data akan diisi melalui AJAX -->
                                    </tbody>
        </table>
        
    </div>
</section>

        
<!-- Portfolio Section-->
<section class="page-section portfolio" id="ekskul">
    <div class="container">
        <!-- Portfolio Section Heading-->
        <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Murid</h2>
        <!-- Icon Divider-->
        <div class="divider-custom">
            <div class="divider-custom-line"></div>
            <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
            <div class="divider-custom-line"></div>
        </div>
        <!-- Portfolio Grid Items-->
        <table id="data-table-murid" class="table table-hover mt-5" style="width:100%"><thead class="thead-dark">
                                    <thead>
                                        <tr>
                                        <th>Nama</th>
                                        <th>NIS</th>
                                        <th>NISN</th>
                                        <th>J/K</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Data akan diisi melalui AJAX -->
                                    </tbody>
        </table>
        
    </div>
</section>

        
        

        
        <!-- About Section-->
        <section class="page-section bg-primary text-white mb-0" id="panduan">
            <div class="container">
                <!-- About Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-white">Panduan Pendaftaran</h2>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- About Section Content-->
                    <p class="lead", align="center">Langkah pertama mendaftar adalah klik tombol sign in, jika belum memiliki akun, harap sign up terlebih dahulu. <br> Kemudian lengkapi data dan berkas yang diminta.</p>
                
                <!-- About Section Button-->
                <div class="text-center mt-4">
                    <a class="btn btn-xl btn-outline-light" href="login.php">
                        Daftar
                    </a>
                </div>
            </div>
        </section>
 


        <!-- Footer-->
        <footer class="footer text-center">
            <div class="container">
                <div class="row">
                    <!-- Footer Location-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">Telepon</h4>
                        <p class="lead mb-0">
                            +62853 xxxx xxxx
                        </p>
                    </div>
                    <!-- Footer Social Icons-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">Media Sosial</h4>
                        <a class="btn btn-outline-light btn-social mx-1" href="#!"><i class="fab fa-fw fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="#!"><i class="fab fa-fw fa-twitter"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="#!"><i class="fab fa-fw fa-linkedin-in"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="#!"><i class="fab fa-fw fa-dribbble"></i></a>
                    </div>
                    <!-- Footer About Text-->
                    <div class="col-lg-4">
                        <h4 class="text-uppercase mb-4">Alamat Sekolah</h4>
                        <p class="lead mb-0">
                            Sungai Lambai
                        </p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Copyright Section-->
        <div class="copyright py-4 text-center text-white">
            <div class="container"><small>Hanifah | 22076118</small></div>
        </div>
        <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes)-->
        <div class="scroll-to-top d-lg-none position-fixed">
            <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top"><i class="fa fa-chevron-up"></i></a>
        </div>
        <!-- Portfolio Modals-->
        <!-- Portfolio Modal 1-->
        <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-labelledby="portfolioModal1Label" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class="fas fa-times"></i></span>
                    </button>
                    <div class="modal-body text-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0" id="portfolioModal1Label">Pramuka</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- Portfolio Modal - Image-->
                                    <img src="assets/img/portfolio/Pramuka.png" alt="" height="400" />
                                    <!-- Portfolio Modal - Text-->
                                    <p class="mb-5">Pramuka adalah kegiatan ekstrakurikuler yang fokus pada pengembangan karakter, keterampilan survival, dan rasa tanggung jawab siswa. Melibatkan kegiatan seperti perkemahan, pelatihan keterampilan bertahan hidup, dan kegiatan sosial.</p>
                                    <button class="btn btn-primary" data-dismiss="modal">
                                        <i class="fas fa-times fa-fw"></i>
                                        Close Window
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio Modal 2-->
        <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-labelledby="portfolioModal2Label" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class="fas fa-times"></i></span>
                    </button>
                    <div class="modal-body text-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0" id="portfolioModal2Label">Tahfidz</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- Portfolio Modal - Image-->
                                    <img src="assets/img/portfolio/Tahfidz.webp" alt="" height="400"/>
                                    <!-- Portfolio Modal - Text-->
                                    <p class="mb-5">Ekskul Tahfidz SMPN 14 Solok Selatan adalah kegiatan ekstrakurikuler di SMP tersebut yang fokus pada pembelajaran dan penghafalan Al-Qur'an. Peserta ekskul akan belajar membaca, memahami, dan menghafal Al-Qur'an secara sistematis dengan bimbingan guru atau instruktur yang kompeten. Tujuan dari ekskul ini adalah untuk membentuk generasi yang memahami dan mengamalkan ajaran agama Islam melalui penghafalan Al-Qur'an.</p>
                                    <button class="btn btn-primary" data-dismiss="modal">
                                        <i class="fas fa-times fa-fw"></i>
                                        Close Window
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio Modal 3-->
        <div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-labelledby="portfolioModal3Label" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class="fas fa-times"></i></span>
                    </button>
                    <div class="modal-body text-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0" id="portfolioModal3Label">Palang Merah Remaja</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- Portfolio Modal - Image-->
                                    <img src="assets/img/portfolio/EnglishClub.png" alt="" height="400"/>
                                    <!-- Portfolio Modal - Text-->
                                    <p class="mb-5">The English Club at SMPN 14 Solok Selatan is a vibrant extracurricular activity dedicated to fostering English language skills and cultural understanding among its members. Through engaging activities such as debates, discussions, language games, and presentations, students have the opportunity to improve their speaking, listening, reading, and writing skills in English. The club also organizes cultural events, movie screenings, and language exchange programs to provide a holistic learning experience. With enthusiastic teachers and supportive peers, the English Club aims to create a fun and dynamic environment where students can develop confidence and fluency in English while expanding their knowledge of global cultures.</p>
                                    <button class="btn btn-primary" data-dismiss="modal">
                                        <i class="fas fa-times fa-fw"></i>
                                        Close Window
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio Modal 4-->
        <div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-labelledby="portfolioModal4Label" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class="fas fa-times"></i></span>
                    </button>
                    <div class="modal-body text-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0" id="portfolioModal4Label">Olahraga</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- Portfolio Modal - Image-->
                                    <img src="assets/img/portfolio/olahraga.png" alt="" height="400" />
                                    <!-- Portfolio Modal - Text-->
                                    <p class="mb-5">Ekstrakurikuler olahraga memberikan siswa kesempatan untuk mengembangkan keterampilan fisik, kerjasama tim, dan kesehatan. Berbagai jenis olahraga, seperti sepak bola, basket, atau atletik, dapat menjadi pilihan untuk meningkatkan kebugaran dan keterampilan atletik.</p>
                                    <button class="btn btn-primary" data-dismiss="modal">
                                        <i class="fas fa-times fa-fw"></i>
                                        Close Window
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio Modal 5-->
        <div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-labelledby="portfolioModal5Label" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class="fas fa-times"></i></span>
                    </button>
                    <div class="modal-body text-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0" id="portfolioModal5Label">Randai</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- Portfolio Modal - Image-->
                                    <img src="assets/img/portfolio/pencak-silat.png" alt="" height="400" />
                                    <!-- Portfolio Modal - Text-->
                                    <p class="mb-5">Ekskul Randai di SMPN 14 Solok Selatan adalah kegiatan ekstrakurikuler yang memperkenalkan dan mengajarkan siswa tentang seni pertunjukan tradisional Minangkabau yang kaya dan berwarna. Dalam ekskul ini, siswa akan belajar gerakan tarian, dialog, serta aspek-aspek lain dari seni pertunjukan randai.</p>
                                    <button class="btn btn-primary" data-dismiss="modal">
                                        <i class="fas fa-times fa-fw"></i>
                                        Close Window
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio Modal 6-->
        <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-labelledby="portfolioModal6Label" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class="fas fa-times"></i></span>
                    </button>
                    <div class="modal-body text-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0" id="portfolioModal6Label">Drumband</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- Portfolio Modal - Image-->
                                    <img src="assets/img/portfolio/Drumband.jpg" alt="" height="400" />
                                    <!-- Portfolio Modal - Text-->
                                    <p class="mb-5">Ekskul Drum dan Band di SMPN 14 Solok Selatan adalah wadah yang memukau di mana siswa dapat menjelajahi dunia perkusi dan pertunjukan musik. Dipimpin oleh instruktur berpengalaman, anggota belajar memainkan berbagai alat musik perkusi seperti drum, simbal, dan seruling, meningkatkan keterampilan ritmis dan koordinasi mereka.</p>
                                    <button class="btn btn-primary" data-dismiss="modal">
                                        <i class="fas fa-times fa-fw"></i>
                                        Close Window
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bootstrap core JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
        <!-- Third party plugin JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
        <!-- Contact form JS-->
        <script src="assets/mail/jqBootstrapValidation.js"></script>
        <script src="assets/mail/contact_me.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>

<script>
  $(document).ready(function(){
      $.get("http://localhost/ekskul/api/index.php?action=guru", function(data){
        fillTable(data);
      });

      $.get("http://localhost/ekskul/api/index.php?action=murid", function(data){
        fillTables(data);
      });

        function fillTable(data) {
        var table = $("#data-table-guru");
        $.each(data, function(index, item){
            var row = $("<tr>");
            $("<td>").text(item.Nama).appendTo(row);
            $("<td>").text(item.NIP).appendTo(row);
            $("<td>").text(item["Jenis Kelamin"]).appendTo(row);
            table.append(row);
        });
        }

        function fillTables(data) {
        var table = $("#data-table-murid");
        $.each(data, function(index, item){
            var row = $("<tr>");
            $("<td>").text(item['NAMA']).appendTo(row);
            $("<td>").text(item['NIS']).appendTo(row);
            $("<td>").text(item["NISN"]).appendTo(row);
            $("<td>").text(item["J\/K"]).appendTo(row);
            table.append(row);
        });
        }
  });
</script>
    </body>
</html>
