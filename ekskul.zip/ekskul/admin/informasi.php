<!doctype html>
<html class="no-js" lang="en">

<?php 
    include '../dbconnect.php';
    include '../cek.php';
    if($role!=='Admin'){
        header("location:../login.php");
    };

    function getLatestID() {
        global $conn;
        
    }

// proses

if(isset($_POST['aksi'])) :

    $aksi = $_POST['aksi'];

    if($aksi == 'tambah') {
        $id_ekskul = null;

        $query = mysqli_query($conn, "SELECT id_informasi FROM informasi ORDER BY id_informasi DESC LIMIT 1");
        if($row = mysqli_fetch_array($query)) {
            $strID = explode("-", $row['id_informasi']);
            $strID[1]++;
            $number = sprintf("%02d", $strID[1]);
            $id_informasi = 'informasi-' . $number;
        }else {
            $id_informasi = 'informasi-01';
        }

        $nama_informasi = $_POST['nama_informasi'];
        $deskripsi = $_POST['deskripsi'];
        $id_ekskul = $_POST['id_ekskul'];
        mysqli_query($conn, "INSERT INTO informasi VALUES ('$id_informasi', '$nama_informasi','$id_ekskul', '$deskripsi')");
    }else if($aksi == 'ubah') {
        $id_informasi = $_POST['id_informasi'];
        $nama_informasi = $_POST['nama_informasi'];
        $deskripsi = $_POST['deskripsi'];
        $id_ekskul = $_POST['id_ekskul'];
        mysqli_query($conn, "UPDATE informasi SET nama_informasi = '$nama_informasi', deskripsi = '$deskripsi', id_ekskul = '$id_ekskul' WHERE id_informasi = '$id_informasi'");
    }else if($aksi == 'hapus') {
        $id_informasi = $_POST['id_informasi'];
        mysqli_query($conn, "DELETE FROM informasi WHERE id_informasi = '$id_informasi'");
    }

endif;

// end proses
?>

<head>
    <meta charset="utf-8">
	<link rel="icon" 
      type="image/png" 
      href="../favicon.png">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Kelola User</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="../assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/themify-icons.css">
    <link rel="stylesheet" href="../assets/css/metisMenu.css">
    <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="../assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
	<!-- Start datatable css -->
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css">
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-144808195-1"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-144808195-1');
	</script>
	
    <!-- others css -->
    <link rel="stylesheet" href="../assets/css/typography.css">
    <link rel="stylesheet" href="../assets/css/default-css.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <!-- modernizr css -->
    <script src="../assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
        <!-- sidebar menu area start -->
        <div class="sidebar-menu">
            <div class="sidebar-header" style="margin-top:-70px;">
                    <a href="index.php"><img src="../logo-putih.png" alt="logo" width="100%"></a>
            </div>
            <div class="main-menu" style="margin-top:-80px;">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
							<li><a href="index.php"><span>Dashboard</span></a></li>
                            <li>
                                <a href="form.php"><i class="ti-layout"></i><span>Formulir</span></a>
                            </li>
                            <li>
                                <a href="user.php"><i class="ti-layout"></i><span>User Terdaftar</span></a>
                            </li>
                            <li>
                                <a href="admin.php"><i class="ti-layout"></i><span>Kelola Admin</span></a>
                            </li>
                            <li >
                                <a href="ekskul.php"><i class="ti-layout"></i><span>Ekskul</span></a>
                            </li>
                            <li >
                                <a href="jadwal.php"><i class="ti-layout"></i><span>Jadwal</span></a>
                            </li >
                            <li  class="active">
                                <a href="informasi.php"><i class="ti-layout"></i><span>Informasi</span></a>
                            </li>
                            <li>
                                <a href="progress.php"><i class="ti-layout"></i><span>Progress</span></a>
                            </li>
                            <li>
                                <a href="artikel.php"><i class="ti-layout"></i><span>Artikel</span></a>
                            </li>
                            <li>
                                <a href="prestasi.php"><i class="ti-layout"></i><span>Prestasi</span></a>
                            </li>
                            <li  >
                                <a href="../logout.php"><span>Logout</span></a>
                                
                            </li>
                            
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            <div class="header-area">
                <div class="row align-items-center">
                    <!-- nav and search button -->
                    <div class="col-md-6 col-sm-8 clearfix">
                        <div class="nav-btn pull-left">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                    <!-- profile info & task notification -->
                    <div class="col-md-6 col-sm-4 clearfix">
                        <ul class="notification-area pull-right">
                            <li><h3><div class="date">
								<script type='text/javascript'>
						<!--
						var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
						var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
						var date = new Date();
						var day = date.getDate();
						var month = date.getMonth();
						var thisDay = date.getDay(),
							thisDay = myDays[thisDay];
						var yy = date.getYear();
						var year = (yy < 1000) ? yy + 1900 : yy;
						document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);		
						//-->
						</script></b></div></h3>

						</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- header area end -->

            <div class="main-content-inner">
               
                <!-- market value area start -->
                <div class="row mt-5 mb-5">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-sm-flex justify-content-between align-items-center">
									<h2>Kelola User</h2>
                                </div>
										 <table id="dataTable3" class="table table-hover" style="width:100%"><thead class="thead-dark">
											<tr>
												<th>No</th>
												<th>Kode Informasi</th>
												<th>Kode Ekskul</th>
												<th>Nama Informasi</th>
												<th>Deskripsi</th>
                                                <th>Aksi</th>
												
											</tr></thead><tbody>
											<?php 
											$form=mysqli_query($conn,"SELECT * FROM informasi ORDER BY id_informasi ASC");
											$no=1;
											while($data=mysqli_fetch_array($form)) :

												?>
												
                                                
												<tr>
													<td><?= $no++ ?></td>
													<td><?= $data['id_informasi'] ?></td>
													<td><?= $data['id_ekskul'] ?></td>
													<td><?= $data['nama_informasi'] ?></td>
                                                    <td><?= $data['deskripsi'] ?></td>
                                                    <td>
                                                        <!-- Button trigger modal -->
                                                        <button type="button" class="btn btn-warning text-white" data-toggle="modal" data-target="#ubahModal"
                                                            onclick="setData('<?= $data['id_informasi'] ?>', '<?= $data['id_ekskul'] ?>', '<?= $data['nama_informasi'] ?>', '<?= $data['deskripsi'] ?>')">
                                                            Ubah Data
                                                        </button>
                                                        <form method="post" class="d-inline">
                                                            <input type="hidden" name="aksi" value="hapus">
                                                            <input type="hidden" name="id_informasi" value="<?= $data['id_informasi'] ?>">
                                                            <button type="submit" class="btn btn-danger" onclick="return confirm('Hapus Data?')">Hapus</button>
                                                        </form>
                                                    </td>
												</tr>		
                                                
                                                <?php endwhile; ?>
										</tbody>
										</table>
                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahModal">
                                            Tambah Data
                                        </button>
									    <a href="exportinformasi.php" target="_blank" class="btn btn-info">Export Data</a>

                                        <!-- Modal -->
                                        <div class="modal fade" id="tambahModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="tambahModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="tambahModalLabel">Tambah Data</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form method="post" id="tambahForm">
                                                    <input type="hidden" name="aksi" value="tambah">
                                                    <div class="mb-3">
                                                        <label>Nama Informasi</label>
                                                        <input type="text" name="nama_informasi" class="form-control">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Deskripsi</label>
                                                        <textarea name="deskripsi" class="form-control"></textarea>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Ekskul</label>
                                                        <select name="id_ekskul" class="form-control">
                                                            <?php 
                                                                $forms=mysqli_query($conn,"SELECT * FROM ekstrakurikuler ORDER BY id_ekskul ASC");
                                                                while($d=mysqli_fetch_array($forms)){
                                                            ?>
                                                            <option value="<?=$d['id_ekskul']?>"><?=$d['nama_ekskul']?></option>
                                                            <?php }?>
                                                        </select>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success" form="tambahForm">Submit</button>
                                            </div>
                                            </div>
                                        </div>
                                        </div>

                                        <!-- Modal -->
                                        <div class="modal fade" id="ubahModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="ubahModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="ubahModalLabel">Ubah Data</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form method="post" id="ubahForm">
                                                    <input type="hidden" name="aksi" value="ubah">
                                                    <input type="hidden" name="id_informasi" id="ubahID">
                                                    <div class="mb-3">
                                                        <label>Nama Informasi</label>
                                                        <input type="text" name="nama_informasi" id="nama_informasi" class="form-control">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Deskripsi</label>
                                                        <textarea name="deskripsi" class="form-control" id="deskripsi"></textarea>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label>Ekskul</label>
                                                        <select name="id_ekskul" class="form-control">
                                                            <?php 
                                                                $forms=mysqli_query($conn,"SELECT * FROM ekstrakurikuler ORDER BY id_ekskul ASC");
                                                                while($d=mysqli_fetch_array($forms)){
                                                            ?>
                                                            <option value="<?=$d['id_ekskul']?>"><?=$d['nama_ekskul']?></option>
                                                            <?php }?>
                                                        </select>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-warning" form="ubahForm">Submit</button>
                                            </div>
                                            </div>
                                        </div>
                                        </div>
									<!-- <a href="exportuser.php" target="_blank" class="btn btn-info">Export Data</a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              
                
                <!-- row area start-->
            </div>
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
        <footer>
            <div class="footer-area">
                <p>Hanifah | 22076118</p>
            </div>
        </footer>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
	
	<script>
		$(document).ready(function() {
		$('input').on('keydown', function(event) {
			if (this.selectionStart == 0 && event.keyCode >= 65 && event.keyCode <= 90 && !(event.shiftKey) && !(event.ctrlKey) && !(event.metaKey) && !(event.altKey)) {
			   var $t = $(this);
			   event.preventDefault();
			   var char = String.fromCharCode(event.keyCode);
			   $t.val(char + $t.val().slice(this.selectionEnd));
			   this.setSelectionRange(1,1);
			}
		});
	
	
	$(document).ready(function() {
    $('#dataTable3').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'print'
        ]
    } );
	} );
	</script>
	
    <!-- jquery latest version -->
    <script src="../assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/owl.carousel.min.js"></script>
    <script src="../assets/js/metisMenu.min.js"></script>
    <script src="../assets/js/jquery.slimscroll.min.js"></script>
    <script src="../assets/js/jquery.slicknav.min.js"></script>
	<!-- Start datatable js -->
	 <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
    <!-- start chart js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
    <!-- start highcharts js -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <!-- start zingchart js -->
    <script src="https://cdn.zingchart.com/zingchart.min.js"></script>
    <script>
    zingchart.MODULESDIR = "https://cdn.zingchart.com/modules/";
    ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "ee6b7db5b51705a13dc2339db3edaf6d"];
    </script>
    <!-- all line chart activation -->
    <script src="../assets/js/line-chart.js"></script>
    <!-- all pie chart -->
    <script src="../assets/js/pie-chart.js"></script>
    <!-- others plugins -->
    <script src="../assets/js/plugins.js"></script>
    <script src="../assets/js/scripts.js"></script>
	
	<script>

    function setData(id_informasi, id_eskuls, nama_informasis, deksripsis) {
        ubahID.value = id_informasi;
        nama_informasi.value = nama_informasis;
        deksripsi.value = deksripsis;
    }

		$(document).ready(function() {
		$('input').on('keydown', function(event) {
			if (this.selectionStart == 0 && event.keyCode >= 65 && event.keyCode <= 90 && !(event.shiftKey) && !(event.ctrlKey) && !(event.metaKey) && !(event.altKey)) {
			   var $t = $(this);
			   event.preventDefault();
			   var char = String.fromCharCode(event.keyCode);
			   $t.val(char + $t.val().slice(this.selectionEnd));
			   this.setSelectionRange(1,1);
			}
		});
	});
	</script>
</body>

</html>
