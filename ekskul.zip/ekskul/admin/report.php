<?php
include('../dbconnect.php');
$u = $_GET['u'];
$cekdulu = mysqli_query($conn,"select * from siswa where nisn='$u'");
    $ambil = mysqli_fetch_array($cekdulu);
    
require_once("../dompdf/autoload.inc.php");
use Dompdf\Dompdf;
$dompdf = new Dompdf();
$query = mysqli_query($conn,"select * from siswa where nisn='$u'");
$html = '
<center><h3>Sistem Pendaftaran Ekstrakurikuler SMPN 14 Sungai Lambai</h3></center><hr/><br/>';
$html .= '<div class="row mt-5 mb-5">
<div class="col-12">
    <div class="card">
        <div class="card-body">
            <div class="d-sm-flex justify-content-between align-items-center">
                <h2>Data Pribadi</h2>
                <img src="../user/'. $ambil['sertifikat'].'" width="20%">
            </div>
            <div class="market-status-table mt-4">
                <div class="table-responsive" style="overflow-x:hidden;">
                    
                    <div class="row">
                        <div class="col">
                        <div class="form-group">
                            <label>NISN</label>
                            <input name="nisn" type="text" class="form-control" value="'.$u.'">
                        </div>
                        </div>
                        <div class="col">
                        <div class="form-group">
                            <label>Hobi</label>
                            <input name="nik" type="text" class="form-control" value="'.$ambil['hobi'].'">
                        </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                        <div class="form-group">
                            <label>Nama Lengkap</label>
                            <input name="namalengkap" type="text" class="form-control" value="'. $ambil['namalengkap'].'">
                        </div>
                        </div>
                        <div class="col">
                        <div class="form-group">
                            <label>Jenis Kelamin</label>
                            <input type="text" class="form-control" value="'. $ambil['jeniskelamin'].'">
                        </select>
                        </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                        <div class="form-group">
                            <label>Kelas</label>
                            <input type="text" class="form-control" value="'.  $ambil['kelas'].'">
                        </div>
                        </div>

                        <div class="col">
                        <div class="form-group">
                            <label>No Telepon</label>
                            <input name="telepon" type="text" class="form-control" maxlength="15" value="'.  $ambil['telepon'].'">
                        </div>
                        </div>
                    </div>
                        
                    </div>
                
                </div>
            </div>
        </div>
    </div>
</div>


<div class="row mt-5 mb-5">
<div class="col-12">
    <div class="card">
        <div class="card-body">
            <div class="d-sm-flex justify-content-between align-items-center">
                <h2>Registrasi Pendaftaran Ekstrakurikuler</h2>
            </div>
            <div class="market-status-table mt-4">
                <div class="table-responsive" style="overflow-x:hidden;">
                    
                    <div class="row">
                        <div class="col">
                        <div class="form-group">
                            <label>Ekstrakurikuler</label>
                            <input name="ekskul" type="text" class="form-control"  value="'. $ambil['ekskul'].'">
                        </div>
                        </div>
                        <div class="col">
                        <div class="form-group">
                            <label>Pengalaman</label>
                            <input name="pengalaman" type="text" class="form-control" value="'. $ambil['pengalaman'].'">
                        </div>
                        </div>
                    </div>

                   

                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                    <label for="sertifikat" class=" form-control-label">Upload Sertifikat Pengalaman, maks 500kb</label>
                                    <img src="../user/'. $ambil['sertifikat'].'" width="50%">
                                </div>
                            </div>
                    </div>

                
                </div>
            </div>
        </div>
    </div>
</div>
</div>';

$html .= "</html>";
$dompdf->loadHtml($html);
// Setting ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'potrait');
// Rendering dari HTML Ke PDF
$dompdf->render();
// Melakukan output file Pdf
$dompdf->stream($u.'.pdf');
?>
